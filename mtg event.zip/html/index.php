<?php

	include "./mydb.php";
		
	$step = '1';
	
		
	function sortsteck($a, $b) {
			global $step;
			global $standings;

			$query = "SELECT *, GROUP_CONCAT(`member_id` SEPARATOR ',') as mach, GROUP_CONCAT(`points` SEPARATOR ',') as scop, GROUP_CONCAT(`order` SEPARATOR ',') as ord FROM `event` where `member_id` in ($a,$b) and step <= ".(int)$step." GROUP BY `step`,`table` HAVING COUNT(`step`) >= 2 AND COUNT(`table`) >= 2";
			$result = mysql_query ($query)
				or die ("Error select TAB_TICKETS: ".mysql_error());
			while ($line = mysql_fetch_array($result, MYSQL_ASSOC)){
				$t1 = split(',', $line['mach']);
				$t2 = split(',', $line['scop']);
				$t3 = split(',', $line['ord']);
					foreach( $t1 as $k => $t11){
						$order2[ $t11 ]['scop'] = $order2[ $t11 ]['scop'] + $t2[$k];
						$order2[ $t11 ]['ord'] = $order2[ $t11 ]['ord'] + $t3[$k];
					}
					
			}
			if ( $order2[$a]['scop'] == $order2[$b]['scop'] ) {
				if ( $order2[$a]['ord'] == $order2[$b]['ord'] ) {
					if( $standings[ $a ]['order'] == $standings[ $b ]['order']){
						//echo "$a(".$standings[ $a ]['name'].") равен order $b(".$standings[ $b ]['name'].") <br>";
						return 0;
					} else if($standings[ $a ]['order'] > $standings[ $b ]['order']){
						//echo "$a(".$standings[ $a ]['name'].") больше по очкамы выбытия $b(".$standings[ $b ]['name'].") <br>";
						return -1;	
					} else {
						return 1;
					}
				
				} else if ( $order2[$a]['ord'] > $order2[$b]['ord'] ) {
					return -1;
				} else {
					return 1;
				}
			}else	if ( $order2[$a]['scop'] > $order2[$b]['scop'] ) {
				return -1;
			}else {
				return 1;
			}
		
	}	
		
	function getmemgers() {
		$arrmembers = [];
		$query = "SELECT * FROM `members`";
		$result = mysql_query ($query)
			or die ("Error select TAB_TICKETS: ".mysql_error());
 		while ($member = mysql_fetch_array($result, MYSQL_ASSOC)){
			$arrmembers[ $member['member_id'] ] = array(
				'id'	 	=> $member['member_id'],
				'name'	=> $member['name'],
				'points'	=> $member['points'],
				'order'	=> $member['order']
			);
		}
		
		return $arrmembers;
	}
	
	function gettables( $step ) {
		$table = [];
			
		$query = "SELECT e.*, m.name, m.status FROM `event` e INNER JOIN `members` m on e.member_id = m.member_id WHERE e.step = ".(int)$step." ORDER BY `e`.`order` DESC ";
		$result = mysql_query ($query)
			or die ("Error select TAB_TICKETS: ".mysql_error());
 		while ($member = mysql_fetch_array($result, MYSQL_ASSOC)){
			
			$table[ $member['table'] ][] = array(
				'id'		=> $member['member_id'],
				'name'		=> $member['name'],
				'step'		=> $member['step'],
				'points'	=> $member['points'],
				'order'		=> $member['order'],
				'status'		=> $member['status']
				
			);
			
		}
		
		if ( count($table) == 0 ){
			for ($i = 0; $i < 5; $i++) { 
				$table[$i][0]['name' ] = 'ФИО_1';
				$table[$i][1]['name' ] = 'ФИО_2';
				$table[$i][2]['name' ] = 'ФИО_3';
				$table[$i][3]['name' ] = 'ФИО_4';
			}
			
		}
		return $table;
		
	}
	function getsteps( ) {
		$query = "SELECT MAX(step) as maxstep FROM event ";
		$result = mysql_query ($query)
			or die ("Error select TAB_TICKETS: ".mysql_error());
			
		$count = mysql_fetch_array ($result, MYSQL_ASSOC);
		
		return $count['maxstep'];
	}
	
	function getpoints( ) {
		$query = "SELECT member_id,SUM(points) as sumpoints FROM `event` GROUP BY member_id ORDER BY `sumpoints`  DESC";
		$result = mysql_query ($query)
			or die ("Error select TAB_TICKETS: ".mysql_error());
 		while ($member = mysql_fetch_array($result, MYSQL_ASSOC)){
			
			$points[ $member['member_id'] ] = $member['sumpoints'];
			
		}
	
		return $points;
	}
	
	
	
	$maxstep = getsteps();
	$step = $maxstep;
	if( isset($_GET['step']) && (int)$_GET['step'] <= $maxstep){
		$step = (int)$_GET['step'];	
		
	}
	
	$members = gettables( $step ); 
	$poins = getpoints();
	
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">

<title>Турнирная сетка Раунд №<?php echo $step;?></title>

<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/jquery-ui.css" rel="stylesheet">
<link href="../css/font-awesome.css" rel="stylesheet">
<link href="../css/template.css?v=27" rel="stylesheet">


<script src="../js/jquery-1.10.2.min.js"></script>

<script src="../js/jquery-ui.min.js"></script>
<script src="../js/jquery.ui.touch-punch.min.js"></script>
<style>
@media print {
	@page {size:landscape;
	}
}
</style>
</head>
<body>
<div class="container">
<div class="masthead">
<h3 class="text-muted">Турнирная сетка</h3>
<ul class="nav nav-justified">
<li class="active"><a href="./index.php">Столы</a></li>
<li><a href="./standings.php">Стендинги</a></li>
<li><a href="./spisok.php">Список игроков</a></li>
<li><a href="#">Результаты</a></li>

</ul>
</div>

<div class="row">
	<div class="col-md-12 steps">
	<?php for($i=1; $i<=$maxstep; $i++){ ?>
	<div class="header"><a href="./index.php?step=<?php echo $i;?>" class="<?php if ($i == $step) echo 'activ';?>" >Раунд №<?php echo $i;?></a></div>
	<?php } ?>
	</div>
</div>
	
	<?php $cont_tables = max(array_keys($members)) +1;
	for( $i = 1; $i < $cont_tables ; $i++ ){ ?>
	<?php
	if( ($i+1) % 2 == 0) {
		echo '<div class="row">';
	}
	?>
	<div class="col-md-6">
		<div id="stol_<?php echo $i; ?>" class="stol">
			<div class="header"> Стол №<?php echo $i; ?></div>
			<div class="tabsheader">
			<span>ФИО</span><span>Очки</span><span>Выбытие</span>
			</div>
			<div class="tabsstat">
				<table class="table table-bordered"><tbody>
					<?php 
						foreach($members[$i] as $member){
							echo '<tr>';
							echo '<td class="name ';
							if ( $member['status'] == 0 ) echo 'status0 '; 
							echo '">'.$member['name'].'</td><td class="stat" >'.$member['points'].'</td><td class="outs " >'.$member['order'].'</td>';
							echo '</tr>';
						}	
					?>
				</tbody></table>
			</div>
		</div>
	</div>
	<?php
	
	if( $i == ($cont_tables - 1) ||  ($i+1) % 2 != 0) {
		echo '</div>';
	}
	?>
	<?php	}  ?>

<div class="row">
	<div class="col-md-6">
	<?php if(count($members[0]) != 0) {  ?>
		<div id="stol_4" class="stol">
			<div class="header"> Бай</div>
			
			<div class="tabsheader">
			<span>ФИО</span><span>Очки</span><span>Выбытие</span>
			</div>
			<div class="tabsstat">
				<table class="table  table-bordered"><tbody>
					<?php 
							foreach($members[0] as $member){
								echo '<tr>';
								echo '<td class="name">'.$member['name'].'</td><td class="stat" >'.$member['points'].'</td><td class="outs">'.$member['order'].'</td>';
								echo '</tr>';
							}	
					?>
				</tbody></table>
			</div>
		</div>
	<?php } ?>
	</div>
</div>

</div>


</div> 

<div style="height: 50px;"></div>


</body>
</html>
