<?php

	include "./mydb.php";
	
	function getmemgers() {
		$arrmembers = [];
		$query = "SELECT * FROM `members`";
		$result = mysql_query ($query)
			or die ("Error select TAB_TICKETS: ".mysql_error());
 		while ($member = mysql_fetch_array($result, MYSQL_ASSOC)){
			$arrmembers[] = array(
				'id'	 	=> $member['member_id'],
				'name'	=> $member['name'],
				'points'	=> $member['points'],
				'order'	=> $member['order'],
				'status'	=> $member['status']
			);
		}
		
		return $arrmembers;
	}
	
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">

<title>Турнирная сетка</title>

<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/jquery-ui.css" rel="stylesheet">
<link href="../css/font-awesome.css" rel="stylesheet">
<link href="../css/template.css?v=27" rel="stylesheet">


<script src="../js/jquery-1.10.2.min.js"></script>
<script src="../js/jquery-ui.min.js"></script>


</head>
<body>
<div class="container">
<div class="masthead">
<h3 class="text-muted">Турнирная сетка</h3>
<ul class="nav nav-justified">
<li ><a href="./index.php">Столы</a></li>
<li ><a href="./standings.php">Стендинги</a></li>
<li class="active"><a href="./spisok.php">Список игроков</a></li>
<li><a href="#">Результаты</a></li>

</ul>
</div>

<div class="row">
	<div class="col-md-12">
	<div class="header">Список участников:</div>
	</div>
	
	
	<div class="col-md-6">
	<table class="table"><tbody>
		<?php 
		$members = getmemgers();
		if ( count($members) > 0 ){
			foreach( $members as $key => $member ){
				echo '<tr>';
				echo '<td>'. (1+$key) .'</td>';
				echo '<td ';
				if ( $member['status'] == 0 ) echo ' class="status0" '; 
				echo '>'. $member['name'] .'</td>';
				echo '</tr>';
			}
		}
		?>
		</tbody></table>
	</div>
	
</div>

<div style="height: 50px;"></div>

<form id="formsend" style="display:none;" method="POST" action="./spisok.php">
</form>

</body>
</html>